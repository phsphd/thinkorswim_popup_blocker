// Run directly in content script context (no injection needed for DOM manipulation)
console.log("[tos-toast-block] starting...");

const TAG = "[tos-toast-block]";
const patterns = [
  /has been submitted/i,
  /SGW:TOSWeb/i,
  /(BUY|SELL)/i,
  /(Weeklys|CALL|PUT|LMT|MKT)/i
];

const hidden = new WeakMap();
const marked = new WeakSet();

const isVisible = (el) => {
  const s = getComputedStyle(el);
  return s.display !== "none" && s.visibility !== "hidden" && s.opacity !== "0";
};

const looksLikeToastContainer = (el) => {
  if (!(el instanceof HTMLElement)) return false;
  const r = el.getBoundingClientRect();
  if (r.width < 250 || r.height < 30 || r.height > 220) return false;

  const s = getComputedStyle(el);
  const posOk = (s.position === "fixed" || s.position === "sticky" || s.position === "absolute");
  if (!posOk) return false;

  const nearTop = r.top >= -5 && r.top <= 200;
  if (!nearTop) return false;

  const z = parseInt(s.zIndex || "0", 10) || 0;
  return z >= 10 || s.position === "fixed" || s.position === "sticky";
};

const hideEl = (el) => {
  if (!el || marked.has(el)) return;
  marked.add(el);
  if (!hidden.has(el)) hidden.set(el, el.getAttribute("style") || "");
  el.style.setProperty("display", "none", "important");
  el.style.setProperty("visibility", "hidden", "important");
  el.style.setProperty("pointer-events", "none", "important");
  el.setAttribute("data-tos-toast-hidden", "1");
  console.log(TAG, "hid:", el);
};

const findAndHide = (root = document) => {
  const nodes = root.querySelectorAll("div, span, p") || [];
  for (const n of nodes) {
    const t = (n.innerText || n.textContent || "").trim();
    if (!t) continue;
    let hits = 0;
    for (const p of patterns) if (p.test(t)) hits++;
    if (hits < 2) continue;
    let best = null;
    let el = n;
    for (let i = 0; i < 20 && el; i++) {
      if (looksLikeToastContainer(el) && isVisible(el)) best = el;
      el = el.parentElement;
    }
    if (best) hideEl(best);
  }
};

// Initial run
findAndHide();

// Watch for new toasts
const mo = new MutationObserver((mutations) => {
  for (const m of mutations) {
    for (const node of m.addedNodes) {
      if (node.nodeType !== 1) continue;
      findAndHide(node);
    }
  }
});
mo.observe(document.documentElement, { childList: true, subtree: true });

console.log(TAG, "active - toasts will be hidden automatically");
