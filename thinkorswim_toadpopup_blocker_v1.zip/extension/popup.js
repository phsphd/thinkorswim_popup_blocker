document.getElementById("activate").addEventListener("click", async () => {
  try {
    const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });

    if (!tab?.id) {
      alert("No tab found");
      return;
    }

    alert("Injecting into: " + tab.url);

    const result = await chrome.scripting.executeScript({
      target: { tabId: tab.id },
      world: "MAIN",
      func: () => {
        try {
          if (window.__tosToastBlock) {
            return "already active";
          }

          const TAG = "[tos-toast-block]";
          const patterns = [
            /has been submitted/i,
            /\bSGW:TOSWeb\b/i,
            /\b(BUY|SELL)\b/i,
            /\b(Weeklys|CALL|PUT|LMT|MKT)\b/i
          ];

          const hidden = new WeakMap();
          const marked = new WeakSet();

          const isVisible = (el) => {
            const s = getComputedStyle(el);
            return s.display !== "none" && s.visibility !== "hidden" && s.opacity !== "0";
          };

          const looksLikeToastContainer = (el) => {
            if (!(el instanceof HTMLElement)) return false;
            const r = el.getBoundingClientRect();
            if (r.width < 250 || r.height < 30 || r.height > 220) return false;

            const s = getComputedStyle(el);
            const posOk = (s.position === "fixed" || s.position === "sticky" || s.position === "absolute");
            if (!posOk) return false;

            const nearTop = r.top >= -5 && r.top <= 200;
            if (!nearTop) return false;

            const z = parseInt(s.zIndex || "0", 10) || 0;
            const overlayish = z >= 10 || s.position === "fixed" || s.position === "sticky";

            return overlayish;
          };

          const hideEl = (el) => {
            if (!el || marked.has(el)) return;
            marked.add(el);

            if (!hidden.has(el)) hidden.set(el, el.getAttribute("style") || "");

            el.style.setProperty("display", "none", "important");
            el.style.setProperty("visibility", "hidden", "important");
            el.style.setProperty("pointer-events", "none", "important");
            el.setAttribute("data-tos-toast-hidden", "1");
            console.log(TAG, "hid:", el);
          };

          const findAndHide = (root = document) => {
            const nodes = root.querySelectorAll?.("div, span, p") || [];
            for (const n of nodes) {
              const t = (n.innerText || n.textContent || "").trim();
              if (!t) continue;

              let hits = 0;
              for (const p of patterns) if (p.test(t)) hits++;
              if (hits < 2) continue;

              let best = null;
              let el = n;
              for (let i = 0; i < 20 && el; i++) {
                if (looksLikeToastContainer(el) && isVisible(el)) best = el;
                el = el.parentElement;
              }
              if (best) hideEl(best);
            }
          };

          findAndHide();

          const mo = new MutationObserver((mutations) => {
            for (const m of mutations) {
              for (const node of m.addedNodes) {
                if (node.nodeType !== 1) continue;
                findAndHide(node);
              }
            }
          });
          mo.observe(document.documentElement, { childList: true, subtree: true });

          window.__tosToastBlock = {
            stop() {
              mo.disconnect();
              console.log(TAG, "stopped");
            },
            restore() {
              mo.disconnect();
              document.querySelectorAll("[data-tos-toast-hidden='1']").forEach(el => {
                const prev = hidden.get(el);
                if (prev) el.setAttribute("style", prev);
                else el.removeAttribute("style");
                el.removeAttribute("data-tos-toast-hidden");
              });
              console.log(TAG, "restored");
            }
          };

          console.log(TAG, "active");
          return "activated";
        } catch (e) {
          return "error: " + e.message;
        }
      }
    });

    alert("Result: " + JSON.stringify(result));
  } catch (err) {
    alert("Injection failed: " + err.message);
  }
});

document.getElementById("stop").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => {
      if (window.__tosToastBlock) window.__tosToastBlock.stop();
    }
  });
});

document.getElementById("restore").addEventListener("click", async () => {
  const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
  if (!tab?.id) return;

  await chrome.scripting.executeScript({
    target: { tabId: tab.id },
    world: "MAIN",
    func: () => {
      if (window.__tosToastBlock) window.__tosToastBlock.restore();
    }
  });
});
