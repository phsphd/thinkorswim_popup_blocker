# ToS Toast Blocker - User Guide

A Chrome extension that automatically hides order confirmation toast notifications on thinkorswim web trading platform.

## Installation

1. Download or clone this extension folder to your computer

2. Open Chrome and go to `chrome://extensions/`

3. Enable **Developer mode** (toggle in the top-right corner)

4. Click **Load unpacked**

5. Select the `extension` folder

6. The extension is now installed and active

## Usage

Once installed, the extension works automatically:

- Navigate to `https://trade.thinkorswim.com/`
- The extension activates on page load
- Order confirmation toasts (slide-in notifications) are automatically hidden
- No button clicks or interaction needed

## What Gets Hidden

The extension hides toast notifications that contain:
- "has been submitted" messages
- Order details (BUY, SELL, CALL, PUT, etc.)
- SGW:TOSWeb references
- Weeklys, LMT, MKT order types

## Verifying It Works

1. Open DevTools (press F12)
2. Go to the Console tab
3. You should see: `[tos-toast-block] active - toasts will be hidden automatically`
4. When a toast is hidden, you'll see: `[tos-toast-block] hid: <element>`

## Disabling the Extension

To temporarily see toasts again:

1. Go to `chrome://extensions/`
2. Find "ToS Toast Blocker"
3. Toggle the switch to disable it
4. Refresh the thinkorswim page

## Troubleshooting

**Extension not working?**
- Make sure the extension is enabled in `chrome://extensions/`
- Refresh the thinkorswim page
- Check the console for `[tos-toast-block]` messages

**Toasts still appearing?**
- The toast may not match the detection patterns
- Open DevTools and check if there are any errors
- Try removing and re-adding the extension

## Uninstalling

1. Go to `chrome://extensions/`
2. Find "ToS Toast Blocker"
3. Click **Remove**
4. Confirm removal
